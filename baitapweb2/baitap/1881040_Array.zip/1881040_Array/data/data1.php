<?php 
	$arrProductCat = array("Fresh Meat","Vegetables","Fruit & Nut Gifts","Fresh Berries","Ocean Foods","Butter & Eggs","Fastfood","Fresh Onion","Papayaya & Crisps","Oatmeal","Fresh Bananas");
	
 ?>
