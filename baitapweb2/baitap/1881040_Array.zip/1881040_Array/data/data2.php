<?php 
	$arrProduct = array(
		array("Fresh Meat", 1, "Thịt bò", "img/product/product-1.jpg", 100 ),
		array("Vegetables", 2, "Rau củ", "img/product/details/product-details-1.jpg", 50 ),
		array("Fruit & Nut Gifts", 3, "Táo", "img/product/product-8.jpg", 30 ),
		array("Fresh Berries", 4, "Nho", "img/product/product-4.jpg", 40 ),
		array("Ocean Foods", 1, "Đùi gà", "img/product/product-10.jpg", 10 ),
		array("Butter & Eggs", 1, "Sữa", "img/product/product-11.jpg", 15 ),
		array("Fastfood", 1, "Hamburger", "img/product/product-5.jpg", 22 ),
		array("Fresh Onion", 1, "xà lách", "img/product/details/product-details-3.jpg", 10 ),
		array("Papayaya & Crisps", 1, "Hạt sấy", "img/product/product-9.jpg", 5 ),
		array("Oatmeal", 1, "Cháo hạnh nhân", "img/product/discount/pd-1.jpg", 27 ),
		array("Fresh Bananas", 1, "Chuối", "img/product/product-2.jpg", 21 ),
	);

 ?>