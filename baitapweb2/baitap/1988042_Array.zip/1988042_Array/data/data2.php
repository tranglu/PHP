<?php 
$products= array(
	"Smartphone1"=>array("1","Samsung Galaxy A7a",400,"Smartphone","images/m1.jpg"),
	"Smartphone2"=>array("2","Oppo A37f",500,"Smartphone","images/m2.jpg"),
	"Smartphone3"=>array("3","Apple Iphone X",400,"Smartphone","images/m3.jpg"),
    "Smartphone4"=>array("4","Infinix Hot S3",350,"Smartphone","images/mk1.jpg"),
    "Smartphone5"=>array("5","Motorola X4",650,"Smartphone","images/mk2.jpg"),
	"Laptop1"=>array("6","Laptop 1",1000,"Laptop","images/mk4.jpg"),
	"Laptop2"=>array("7","Laptop 2",1200,"Laptop","images/mk5.jpgg"),
	"Laptop3"=>array("8","Laptop 3",1500,"Laptop","images/mk6.jpg"),
	"Sound1"=>array("9","Sound 1",44,"Sound","images/m5.jpg"),
	"Sound2"=>array("10","Sound 2",56,"Sound","images/m6.jpg"),
	"Sound3"=>array("11","Sound 3",74,"Sound","images/mm2.jpg"),
	"Photography1"=>array("12","Photography 1",55,"Photography","images/a4.jpg"),
    "Photography2"=>array("13","Photography 2",26,"Photography","images/b3.jpg"),
    "Photography3"=>array("14","Photography 3",65,"Photography","images/mm3.jpg")
	);
?>