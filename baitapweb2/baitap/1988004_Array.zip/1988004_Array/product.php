<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <title>1988004_Array Products</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="styles/layout.css" type="text/css">
    <!--[if lt IE 9]><script src="scripts/html5shiv.js"></script><![endif]-->
</head>

<body>
    <div class="wrapper row1">
        <?php
        include("components/menu.php")
        ?>
    </div>
    <!-- content -->
    <div class="wrapper row2">
        <div id="container" class="clear">
            <?php
            include("components/leftnav.php")
            ?>
            <!-- main content -->
            <div id="content">
                <?php
                include("data/data2.php");
                echo '<table border="0" width="100%">';

                $last = count($product) - 1;

                if ($last % 2 != 0) {
                    for ($i = 0; $i < count($product); $i++) {
                        if ($i % 2 == 0) {
                            echo '<tr><td>';
                            echo 'ID: ' . $product['maso'] . '<br/>';
                            echo 'Product Name: ' . $product['ten'] . '<br/>';
                            echo 'URL: ' . $product['url'] . '<br/>';
                            echo 'Price: ' . $product['gia'] . '<br/>';
                            echo 'Category: ' . $product['thuoc'] . '<br/>';
                            echo 'Sale: ' . $product['khuyenmai'] . '<br/>';
                            echo '</td>';
                        } else {
                            echo '<td>';
                            echo 'ID: ' . $product['maso'] . '<br/>';
                            echo 'Product Name: ' . $product['ten'] . '<br/>';
                            echo 'URL: ' . $product['url'] . '<br/>';
                            echo 'Price: ' . $product['gia'] . '<br/>';
                            echo 'Category: ' . $product['thuoc'] . '<br/>';
                            echo 'Sale: ' . $product['khuyenmai'] . '<br/>';
                            echo '</td></tr>';
                        }
                    }
                } else {
                    for ($i = 0; $i < count($product); $i++) {
                        if ($i % 2 == 0) {
                            if ($i == $last) {
                                echo '<tr><td>';
                                echo 'ID: ' . $product['maso'] . '<br/>';
                                echo 'Product Name: ' . $product['ten'] . '<br/>';
                                echo 'URL: ' . $product['url'] . '<br/>';
                                echo 'Price: ' . $product['gia'] . '<br/>';
                                echo 'Category: ' . $product['thuoc'] . '<br/>';
                                echo 'Sale: ' . $product['khuyenmai'] . '<br/>';
                                echo '</td><td></td></tr>';
                            } else {
                                echo '<tr><td>';
                                echo 'ID: ' . $product['maso'] . '<br/>';
                                echo 'Product Name: ' . $product['ten'] . '<br/>';
                                echo 'URL: ' . $product['url'] . '<br/>';
                                echo 'Price: ' . $product['gia'] . '<br/>';
                                echo 'Category: ' . $product['thuoc'] . '<br/>';
                                echo 'Sale: ' . $product['khuyenmai'] . '<br/>';
                                echo '</td>';
                            }
                        } else {
                            echo '<td>';
                            echo 'ID: ' . $product['maso'] . '<br/>';
                            echo 'Product Name: ' . $product['ten'] . '<br/>';
                            echo 'URL: ' . $product['url'] . '<br/>';
                            echo 'Price: ' . $product['gia'] . '<br/>';
                            echo 'Category: ' . $product['thuoc'] . '<br/>';
                            echo 'Sale: ' . $product['khuyenmai'] . '<br/>';
                            echo '</td></tr>';
                        }
                    }
                }
                echo '</table>';
                ?>
            </div>
            <!-- / content body -->
        </div>
    </div>
    <!-- footer -->
    <div class="wrapper row3">
        <?php
        include("components/footer.php")
        ?>
    </div>

</body>

</html>