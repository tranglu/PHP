  <header id="header" class="clear">
      <div id="hgroup">
          <h1><a href="#">1988004_Array</a></h1>
          <h2>Bai Tap PHP Array</h2>
      </div>
      <nav>
          <ul>
              <li><a href="./index.php">HOME</a></li>
              <li><a href="./product.php">PRODUCTS</a></li>
              <li><a href="./productcat.php">CATEGORIES</a></li>
              <li class="last"><a href="./contact.php">CONTACT</a></li>
          </ul>
      </nav>
  </header>