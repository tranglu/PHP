  <footer id="footer" class="clear">
      <p class="fl_left">Copyright &copy; 2020 - 1988004_Array</p>
      <p class="fl_right">Bai Tap PHP Array</p>
  </footer>