<?php

$Cat_Array = array('Food','Drinks');
$Cat_Array_URL = array('food.png','drinks.png');

$Cat_0_Array = array('Meat and fish', 'Vegetables and fruit');
$Cat_0_Array_URL = array('meat_fish.png', 'vegetables_fruits.png');

$Cat_1_Array = array('Soft drinks','Alcoholic drinks');
$Cat_1_Array_URL = array('soft_drinks.png','alcoholic_drinks.png');


?>