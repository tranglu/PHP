<?php

$product = array(
    array(
        "maso" => "1",
        "ten" => "Beef Meat",
        "url" => "beef_meat.png",
        "gia" => 200000,
        "thuoc" => "Meat and fish",
        "khuyenmai" => 0.02
    ),
    array(
        "maso" => "2",
        "ten" => "Fish",
        "url" => "fish.png",
        "gia" => 100000,
        "thuoc" => "Meat and fish",
        "khuyenmai" => 0.02
    ),
    array(
        "maso" => "3",
        "ten" => "Cocacola",
        "url" => "cocacola.png",
        "gia" => 10000,
        "thuoc" => "Soft drinks",
        "khuyenmai" => 0.02
    ),
    array(
        "maso" => "4",
        "ten" => "Heineken Beer",
        "url" => "heineken_beer.png",
        "gia" => 30000,
        "thuoc" => "Alcoholic drinks",
        "khuyenmai" => 0.02
    ),
    array(
        "maso" => "5",
        "ten" => "Pork",
        "url" => "pork.png",
        "gia" => 150000,
        "thuoc" => "Meat and fish",
        "khuyenmai" => 0.02
    ),
    array(
        "maso" => "6",
        "ten" => "Potatoes",
        "url" => "potatoes.png",
        "gia" => 50000,
        "thuoc" => "Vegetables and fruit",
        "khuyenmai" => 0.02
    )
);
